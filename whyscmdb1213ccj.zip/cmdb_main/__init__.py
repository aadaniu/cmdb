'''
    for python3 use pymysql to replace MySQLdb
'''
import pymysql
pymysql.install_as_MySQLdb()